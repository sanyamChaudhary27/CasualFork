# Source Index

This is a convenience index, not a substitute for re-verification.

## OpenCode (checked 2026-08-24)

- Agents V2: https://opencode.ai/v2/docs/agents
- Permissions V2: https://opencode.ai/v2/docs/permissions
- Config V2: https://opencode.ai/v2/docs/config
- Models V2: https://opencode.ai/v2/docs/models
- Skills: https://opencode.ai/docs/skills
- Server API: https://opencode.ai/docs/server/
- SDK: https://opencode.ai/docs/sdk/
- Custom tools: https://opencode.ai/docs/custom-tools/
- CLI / upgrade: https://opencode.ai/docs/cli/

## Causal/world-model research

- Twin Rollouts: https://arxiv.org/abs/2608.08982
- CG-World: https://arxiv.org/abs/2607.26452
- EVOKE paper: https://arxiv.org/abs/2608.13546
- EVOKE code: https://github.com/AlayaLab/Evoke
- EVOKE model: https://huggingface.co/AlayaLab/Evoke
- Yume paper: https://arxiv.org/abs/2507.17744
- Yume code: https://github.com/stdstu12/YUME
- RLVR-World: https://arxiv.org/abs/2505.13934
- PersistWorld: https://github.com/Jai2500/PersistWorld
- Image2World competitive example: https://github.com/TingdeLiu/Image2world

Any agent using a source for a public claim should revisit the canonical source at the time of use.
