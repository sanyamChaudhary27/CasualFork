---
name: research-paper-audit
description: Audit a paper or research claim for exact contribution, release status, empirical evidence, assumptions, dates, code/weights, and what must not be overclaimed.
---
# Research Paper Audit

Use when a project decision depends on a paper.

1. Identify exact title, authors, version/date, and canonical source.
2. Read abstract plus the method/experiments sections relevant to the claim.
3. Separate: proposed method, demonstrated result, future work, and speculation.
4. Verify whether code, weights, data, and evaluation scripts actually exist.
5. Record hardware/dataset/benchmark conditions for performance claims.
6. Check whether later revisions or official repo notes contradict the paper headline.
7. State what the source establishes and what it does not.
8. Add a public-claim wording recommendation.

Never cite a search snippet as the primary evidence when the paper/repo is available.
