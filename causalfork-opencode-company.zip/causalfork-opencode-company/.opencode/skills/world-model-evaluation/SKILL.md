---
name: world-model-evaluation
description: Evaluate interactive video world-model rollouts for camera fidelity, spatial identity, geometry, temporal coherence, prompt adherence, drift, and compute cost.
---
# World Model Evaluation

Evaluate a rollout on separate axes:

- camera/control fidelity;
- frame-level visual quality;
- temporal consistency;
- long-horizon identity drift;
- geometry/depth consistency;
- revisitation consistency if the path returns to a place;
- prompt/intervention adherence;
- latency / generated-seconds-per-wall-second;
- peak VRAM and host RAM.

Use the same serialized camera path for backend comparisons. Do not average away a catastrophic axis. Preserve raw per-axis metrics and videos.
