---
name: demo-export
description: Turn a verified branch experiment into a short, honest hero demo with synchronized A/B timing, clear intervention, provenance, and no misleading latency or causality claims.
---
# Demo Export

A hero clip should contain only what is needed to understand the magic:

1. source image;
2. movement beyond source view;
3. fork marker;
4. factual/counterfactual synchronized continuation;
5. intervention label;
6. optional compact metric/technical tag.

Keep both branches on the same camera timeline. Preserve the original experiment artifacts separately from any edited social clip. If generation was buffered/offline, do not edit the clip to imply measured real-time inference.

Record hero seed/candidate count so selection is transparent.
