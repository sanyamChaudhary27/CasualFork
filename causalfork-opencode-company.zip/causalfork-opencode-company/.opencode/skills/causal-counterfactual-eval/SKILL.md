---
name: causal-counterfactual-eval
description: Evaluate a factual/counterfactual branch pair under explicit invariants, intervention targets, shared prefix/control/noise policy, and minimal-change/locality criteria.
---
# Counterfactual Evaluation

Before scoring, write the intervention contract:

- what is deliberately changed;
- what must remain invariant;
- what downstream changes are logically allowed;
- whether prefix, controls, and noise are exactly shared or only approximately matched.

For synthetic scenes, compute against simulator truth: changed-object/region masks, depth, segmentation, camera matrices, state variables.

For real scenes, combine geometry/features with human paired review. Use learned VLM/CLIP judges primarily for semantic adherence, not as the sole proof of causal locality.

Report a vector: intervention, identity, geometry, temporal, camera, locality, artifacts. Reward weights must be disclosed.
