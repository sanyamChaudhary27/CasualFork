---
name: git-worktree-isolation
description: Isolate parallel OpenCode builders into separate Git worktrees/branches so agents can work concurrently without corrupting the same files or notebook.
---
# Git Worktree Isolation

Use only when parallel edits are genuinely valuable.

1. Ensure the main worktree is clean or changes are intentionally committed/stashed.
2. Create one branch/worktree per builder with clear ownership.
3. Give each agent the exact worktree and files it owns.
4. Do not edit the same file in two worktrees unless planning an explicit manual merge.
5. Each builder runs its own verification and commits a small coherent change.
6. Reviewer inspects commits/diffs before merge.
7. Orchestrator merges one branch at a time and reruns integration checks.

Never use worktrees as an excuse to let multiple agents redesign the same notebook concurrently.
